package classes.client;
import java.util.*;

import classes.superclasses.Card;
import classes.enums.CardSign;
import classes.enums.CardValue;
import classes.abstracts.CardGame;
import classes.subclasses.Poker;
import classes.subclasses.Bridge;
public class PlayCardGames{
	public static void main(String[] args){
		Scanner scan;
		try{
			String option1;
			scan = new Scanner(System.in);
			int score;
			while(true){
				System.out.println("Select an option:");
				System.out.println("Type \"P\" to play a round of Poker");   
				System.out.println("Type \"B\" to play a round of Bridge");
				System.out.println("Type \"Q\" to Quit");
				option1=scan.nextLine();
		   
			switch (option1) {         
				case "P":   Poker p = new Poker();
							System.out.println("\n" + p.displayDescription());
							p.deal();
							int sc = p.getScore();
							System.out.println("\n\nCompare the two hands:");
							if(sc < 0)
								System.out.println("Dealer Wins :-(");
							else if (sc == 0)
								System.out.println("Its a draw");
							else if (sc > 0)
								System.out.println("Congrats You win !!");
							else
								System.out.println("Somethings wrong!");
							break;
				
				case "B":	Bridge b = new Bridge();
							System.out.println("\n" + b.displayDescription());
							b.deal();
							int s = b.getScore();
							System.out.println("\n\nCompare the two hands:");
							if(s < 0)
								System.out.println("Dealer Wins :-(");
							else if (s == 0)
								System.out.println("Its a draw");
							else if (s > 0)
								System.out.println("Congrats You win !!");
							else
								System.out.println("Somethings wrong!");
							break;
			
				case "Q":   System.out.println("Quitting program");
							System.exit(0);
			   
				default: System.out.println("Wrong option! Try again");
					break;
				}   
			}
		  }catch(Exception e){ 
		   System.out.println("Invalid Input");
		  }
	}
}