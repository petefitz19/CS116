package classes.abstracts;
import java.util.*;
import classes.superclasses.Card;
import classes.enums.CardSign;
import classes.enums.CardValue;
public abstract class CardGame{
	protected ArrayList<Card> deck = new ArrayList<Card>(52);
	
	public CardGame(){
		int count = 0;
		for(int i = 0; i < 4; i++){
			for(int j = 0; j < 13; j++){
				deck.add(new Card(CardSign.values()[i], CardValue.values()[j]));
				System.out.println(deck.get(count).toString());
				count++;
			}
		}
	}
	public void shuffle(){
		Collections.shuffle(deck);
	}
	public abstract String displayDescription();
	public abstract void deal();
}