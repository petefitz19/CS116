package classes.subclasses;
import java.util.*;

import classes.superclasses.Card;
import classes.enums.CardSign;
import classes.enums.CardValue;
import classes.abstracts.CardGame;

public class Poker extends CardGame{
	private int handSize = 5;
	private ArrayList<Card> playerHand;
	private ArrayList<Card> dealerHand;
	
	public Poker(){
		super();
		playerHand = new ArrayList<Card>(handSize);
		dealerHand = new ArrayList<Card>(handSize);
	}
	
	public String displayDescription(){
		String ret = "This game of Poker will compare the  5 cards " + "\n" +
		"of the dealer and player and provide a score." + "\n" +
		"If the score is zero, it means the game is a tie." +"\n" +
		"If the score is positive, then the player has won the game";
		return ret;
	}
	public void deal(){
		super.shuffle();
		for(int i = 0; i < handSize; i++){
			playerHand.add(deck.get(i));
			dealerHand.add(deck.get(i+handSize));
		}
		System.out.println("\n" + "Player's Hand: ");
		for(int j = 0; j < handSize; j++){
			System.out.println(playerHand.get(j).toString());
		}
		System.out.println("\n" + "Dealer's Hand: ");
		for(int k = 0; k < handSize; k++){
			System.out.println(dealerHand.get(k).toString());
		}
	}
	public int getScore(){
		int score = 0;
		for(int i = 0; i < handSize; i++){
			if(playerHand.get(i).getSign().ordinal()>dealerHand.get(i).getSign().ordinal())
				score++;
			else if(playerHand.get(i).getSign().ordinal()<dealerHand.get(i).getSign().ordinal())
				score--;
			else if(playerHand.get(i).getSign().ordinal()==dealerHand.get(i).getSign().ordinal())
			{
				if(playerHand.get(i).getValue().ordinal()>dealerHand.get(i).getValue().ordinal())
					score++;
				else if(playerHand.get(i).getValue().ordinal()<dealerHand.get(i).getValue().ordinal())
					score--;
				else if(playerHand.get(i).getValue().ordinal()==dealerHand.get(i).getValue().ordinal())
					score = score;
			}
		}
		return score;
	}

}