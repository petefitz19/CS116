package classes.enums;
public enum CardSign {SPADE,CLUB,DIAMOND,HEART};
