package classes.superclasses;
import classes.enums.CardSign;
import classes.enums.CardValue;
public class Card{
	private CardSign sign;
	private CardValue value;
	
	public Card(CardSign sign, CardValue value){
		this.setCardSign(sign);
		this.setCardValue(value);
	}
	public CardSign getSign(){
		return this.sign;
	}
	public CardValue getValue(){
		return this.value;
	}
	
	public void setCardSign(CardSign sign){
		this.sign = sign;
	}
	public void setCardValue(CardValue value){
		this.value = value;
	}
	public String toString(){ 
		return "Card: " + this.value + " of " + this.sign; 
	}   
}