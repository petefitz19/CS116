package classes.subclasses;
import classes.abstractClasses.Loan;
public class BusinessLoan extends Loan{
	private double primeRate;
	public BusinessLoan(String lastName, double loanAmount, int term, double primeRate){
		super(lastName, loanAmount, term);
		this.setPrimeRate(primeRate);
		super.interestRate = 0.01 / (primeRate / 100);
	}
	public double getPrimeRate(){
		return this.primeRate;
	}
	public void setPrimeRate(double primeRate){
		this.primeRate = primeRate;
	}
	public String toString(){
		return super.toString() + "Prime Rate: " + this.getPrimeRate() + "\n" + "Loan Type: Business" + "\n";
	}
}