package classes.client;
import java.util.*;
import classes.abstractClasses.Loan;
import classes.subclasses.BusinessLoan;
import classes.subclasses.PersonalLoan;

public class CreateLoans{
	private static Loan[] loans = new Loan[5];
	
	public static void main(String[] args){
		CreateLoans l = new CreateLoans();
		String loanType;
		double currentPrime;
		String lastName;
		double loanAmount;
		int term;
		int count = 0;
		while(count < 5){
			loanType = l.readLoanType();
			currentPrime = l.readCurrentPrime();
			lastName = l.readLastName();
			loanAmount = l.readLoanAmount();
			term = l.readTerm();
			
			if(loanType.equals("P")){
				l.loans[count] = new PersonalLoan(lastName, loanAmount, term, currentPrime);
				count++;
			}
			if(loanType.equals("B")){
				l.loans[count] = new BusinessLoan(lastName, loanAmount, term, currentPrime);
				count++;
			}
		}
		for(int i = 0; i < count; i++){
			System.out.println(l.loans[i].toString());
		}
		
	}
	/* public static void getErrorMessage(String s, Exception error){
		if(error.getMessage()==null){
			System.out.println("Unnaccepted Input. Please Enter " + s + " again.");
		}
		else{
			System.out.println(error.getMessage());
		}
	} */
	public static String readLoanType(){
		Scanner scan = new Scanner(System.in);
		String type;
		
		try{
			System.out.println("Enter 'P' for a Personal Loan or 'B' for a Business Loan");
			type = scan.nextLine();
			if(type.equals("P"))
				return type;
			else if(type.equals("B"))
				return type;
			else throw(new Exception("Error. Please enter a valid Input"));
		}catch(Exception error){
			System.out.println("Invalid Input");
			return readLoanType();
		}
	}
	public static double readCurrentPrime(){
		Scanner scan = new Scanner(System.in);
		double primeRate;
		
		try{
			System.out.println("Enter prime interest rate __%");
			primeRate = scan.nextDouble();
			if(primeRate <=0.0)
				throw(new Exception());
			return primeRate;
		}catch(Exception error){
			System.out.println("Invalid Input");
			return readCurrentPrime();
		}
	}
	public static String readLastName(){
		Scanner scan = new Scanner(System.in);
		String lastName;
		
		try{
			System.out.println("Enter customer Last Name: ");
			lastName = scan.next();
			return lastName;
		}catch(Exception error){
			System.out.println("Invalid Input");
			return readLastName();
		}
	}
	public static double readLoanAmount(){
		Scanner scan = new Scanner(System.in);
		double loanAmount;
		
		try{
			System.out.println("Enter Loan Amount: ");
			loanAmount = scan.nextDouble();
			if(loanAmount <=0)
				throw(new Exception());
			else if (loanAmount > 100000)
				throw(new Exception());
			return loanAmount;
		}catch(Exception error){
			System.out.println("Invalid Input");
			return readLoanAmount();
		}
	}
	public static int readTerm(){
		Scanner scan = new Scanner(System.in);
		int term;
		
		try{
			System.out.println("Enter a Term: 1, 3, or 5: ");
			term = scan.nextInt();
			if(term ==1)
				return term;
			else if(term ==3)
				return term;
			else if(term == 5)
				return term;
			else throw(new Exception());
		}catch(Exception error){
			System.out.println("Invalid Input");
			return readTerm();
		}
	}
}