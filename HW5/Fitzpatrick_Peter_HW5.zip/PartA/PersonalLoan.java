package classes.subclasses;
import classes.abstractClasses.Loan;
public class PersonalLoan extends Loan{
	private double primeRate;
	public PersonalLoan(String lastName, double loanAmount, int term, double primeRate){
		super(lastName, loanAmount, term);
		this.setPrimeRate(primeRate);
		super.interestRate = 0.02 / (primeRate / 100);
	}
	public double getPrimeRate(){
		return this.primeRate;
	}
	public void setPrimeRate(double primeRate){
		this.primeRate = primeRate;
	}
	public String toString(){
		return super.toString() + "Prime Rate: " + this.getPrimeRate() + "\n" + "Loan Type: Personal" + "\n";
	}
}