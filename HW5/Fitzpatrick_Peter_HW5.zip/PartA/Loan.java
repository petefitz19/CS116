package classes.abstractClasses;
import classes.interfaces.LoanConstants;
public abstract class Loan implements LoanConstants{
	private int loanNumber;
	private static int count = 10000;
	private String lastName;
	private double loanAmount;
	protected double interestRate;
	private int term;
	public Loan(){
		this.loanNumber = count++;
		this.setLastName(COMPANY_NAME);
		this.setLoanAmount(MAXIMUM_LOAN_AMOUNT);
		this.setTerm(MEDIUM_TERM);
	}
	public Loan(String lastName, double loanAmount, int term){
		this.loanNumber = count++;
		this.setLastName(lastName);
		this.setLoanAmount(loanAmount);
		this.setTerm(term);
	}
	public void setLastName(String lastName){
		this.lastName = lastName.toUpperCase();
	}
	public void setLoanAmount(double loanAmount){
		if(loanAmount > MAXIMUM_LOAN_AMOUNT)
			this.loanAmount = MAXIMUM_LOAN_AMOUNT;
		else this.loanAmount = loanAmount;
	}
	public void setTerm(int term){
		if(term == SHORT_TERM || term == MEDIUM_TERM || term == LONG_TERM)
			this.term = term;
		else this.term = SHORT_TERM;
	}
	public int getLoanNumber(){
		return this.loanNumber;
	}
	public String getLastName(){
		return this.lastName;
	}
	public double getLoanAmount(){
		return this.loanAmount;
	}
	public double getInterestRate(){
		return this.interestRate;
	}
	public int getTerm(){
		return this.term;
	}
	public String toString(){
		String ret = "Loan Number: " + this.getLoanNumber() + "\n";
		ret += "Last Name: " + this.getLastName() + "\n";
		ret += "Loan Amount: " + this.getLoanAmount() + "\n";
		ret += "Interest Rate: " + this.getInterestRate() + "\n";
		ret += "Term: " + this.getTerm() + "\n";
		return ret;
	}
}
