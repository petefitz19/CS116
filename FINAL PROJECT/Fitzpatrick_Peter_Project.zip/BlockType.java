package Traffic.RoadNetwork;
/**
 *  Enums of the type of blocks that make up each lane
 */
public enum BlockType{
	BLOCK_NORMAL, BLOCK_TRAFFIC, BLOCK_INTERSECT 
};