package Traffic.RoadNetwork;
/**
 *  Enums of direction of the lanes to distiguish them from one another
 */
public enum LaneType{
	NS, SN, WE, EW
};