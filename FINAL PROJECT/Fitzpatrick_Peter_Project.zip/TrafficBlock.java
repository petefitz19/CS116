package Traffic.RoadNetwork;

import Traffic.RoadNetwork.BlockType;
import Traffic.RoadNetwork.Block;
import Traffic.RoadNetwork.TrafficLight;
/**
 *  TrafficBlock.java - A subclass of the Block class.
 *	The traffic flowing into the intersection are controlled by traffic lights.
 *	There is only one traffic block for each lane and the traffic lights for the 
 *	lane is situtated in the Block. A vehicle in a
 *	traffic block can move forward only if the appropriate traffic light i.e. GREEN or
 *	ORANGE is on.
 *	@author	Peter Fitzpatrick
 *	@version 1.0
 */
public class TrafficBlock extends Block{
	private TrafficLight color;
	/**
	*	Constructor for class IntersectionBlock.
	*	Takes in parameters of an integer representing its Block Number, 
	*	the type of intersection block it is as the IntersectionType enum class,
	*	and a double representing the rate at which a vehicle can turn.
	*	@param	no	an integer value representing the number of the Intersection Block.
	*	@param	color	a variable of the TrafficLight enum class
	*/
	public TrafficBlock(int no, TrafficLight color){
		super(BlockType.BLOCK_TRAFFIC, no);
		this.setColor(color);
	}
	/**
	*	Sets the color of the Traffic Light
	*	@param	color	a TrafficLight enum value
	*	@see TrafficLight
	*/
	public void setColor(TrafficLight color){
		this.color = color;
	}
	/**
	*	Returns the color of the TrafficLight
	*	@return a TrafficLight enum value
	*	@see TrafficLight
	*/
	public TrafficLight getColor(){
		return this.color;
	}
	/**
	*	A method to move the vehicle to the next place in the road
	*	@param tick	the current tick that the simulation is on
	*	@return	an object of type Auto
	*/
	@Override
	public Auto MoveForward(int tick){
		if(this.getColor() != TrafficLight.RED && super.getNext().getAuto() == null){
			Auto temp = super.getAuto();
			super.getNext().setAuto(temp);
			super.setAuto(null);
			super.setProcessedFlag(true);
			return null;
		}// set this block to null, set next block to auto
		else if(super.getNext()== null){
			super.setAuto(null);
			this.setProcessedFlag(true);
			return null;
		}
		else{
			this.setProcessedFlag(true);
			return null;
		}
	}
}