package Traffic.RoadNetwork;
/**
 *  Enums of the type of intersection block.
 *	It may be one that allows a right turn,
 *	or one that allows a left turn.
 */
public enum IntersectionType{
	LEFT, RIGHT 
};