package Traffic.RoadNetwork;
/**
 *  Enums of the colors of the traffic light for the Traffic Block
 */
public enum TrafficLight{
	GREEN, ORANGE, RED
};